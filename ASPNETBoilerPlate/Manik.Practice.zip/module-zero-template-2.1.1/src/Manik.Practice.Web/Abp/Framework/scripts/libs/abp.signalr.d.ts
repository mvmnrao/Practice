﻿declare namespace abp {

    namespace signalr {

        let autoConnect: boolean;

        function connect(): any;

        namespace hubs {

            let common: any;

        }

    }

}