using Manik.Practice.Configuration.Ui;

namespace Manik.Practice.Web.Models.Layout
{
    public class RightSideBarViewModel
    {
        public UiThemeInfo CurrentTheme { get; set; }
    }
}