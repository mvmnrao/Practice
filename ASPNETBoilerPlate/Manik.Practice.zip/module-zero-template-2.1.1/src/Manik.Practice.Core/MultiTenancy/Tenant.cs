﻿using Abp.MultiTenancy;
using Manik.Practice.Authorization.Users;

namespace Manik.Practice.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}