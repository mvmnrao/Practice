﻿namespace Manik.Practice
{
    public class PracticeConsts
    {
        public const string LocalizationSourceName = "Practice";

        public const bool MultiTenancyEnabled = true;
    }
}